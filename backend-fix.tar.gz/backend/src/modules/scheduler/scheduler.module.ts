import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { SchedulerService } from './scheduler.service';
// import { GmailModule } from '../gmail/gmail.module';
import { BackupModule } from '../резервное-копирование/backup.module';
import { LoggerModule } from '../logger/logger.module';

@Module({
  imports: [ScheduleModule.forRoot(), /* GmailModule, */ BackupModule, LoggerModule],
  providers: [SchedulerService],
})
export class SchedulerModule {}
